<?php

require '../app/functions/functions.php';
load();