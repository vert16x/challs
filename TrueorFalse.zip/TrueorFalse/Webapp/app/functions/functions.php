<?php

function load()
{
    if(!isset($_GET['auth'])){
        require '../views/home.php';
    }
    if(isset($_GET['auth']) && $_GET['auth'] == 'false'){
        require '../views/denied.php';
    }
    if(isset($_GET['auth']) && $_GET['auth'] == 'true'){
        require '../views/admin.php';
    }
    
    
}