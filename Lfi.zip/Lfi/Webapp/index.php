<?php
   $file = $_GET['q'];
   if(isset($file))
   {
        if(!file_exists($file)){
            die("Page not found.");
        }
        include($file);
   }
   else
   {
       include("home.php");
   }
?>
