from flask import Flask, session, redirect,url_for,render_template,request
import functools,os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'iloveyou'

#CATHO-CTF{Cr4ck-F0rg3-&-C0mm4nD-1nj3ct10n}
@app.route('/')
def index():
    if 'admin' not in session:
        session['admin'] = False
        session['logged_in'] = False

    if session['admin'] and session['logged_in']:
        return redirect(url_for('home'))
    else:
        
        return render_template('403.html'),403


@app.route('/home', methods = ['POST', 'GET'])
def home():
    if session['admin'] and session['logged_in']:
        if request.method == 'POST':
            address = request.form.get('availability')
            cmd = "ping -c 2 %s" %address
            resp = os.popen(cmd).read()
            
            return render_template('home.html',resp=resp)
        else:
            return render_template('home.html')

    
    else:
        return render_template('403.html'),403


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')
    


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=False)
