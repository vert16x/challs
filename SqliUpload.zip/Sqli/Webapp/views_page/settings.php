<?php
ob_start();

include("../config.php");
if (!$_SESSION["username"])
{
    die(header('Location: /?page=home'));
}

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Settings</title>
</head>
<body>
<div class="fixed top-0 left-0 h-full w-1/2 bg-white" aria-hidden="true"></div>
<div class="fixed top-0 right-0 h-full w-1/2 bg-gray-50" aria-hidden="true"></div>
<div class="relative flex min-h-full flex-col">
  <!-- Navbar -->
  <nav class="flex-shrink-0 bg-gray-800">
    <div class="mx-auto max-w-7xl px-2 sm:px-4 lg:px-8">
      <div class="relative flex h-16 items-center justify-between">
        <!-- Logo section -->
        <div class="flex items-center px-2 lg:px-0 xl:w-64">
          <div class="flex-shrink-0">
            <img class="h-8 w-auto" src="https://tailwindui.com/img/logos/mark.svg?color=indigo&shade=300" alt="Your Company">
          </div>
        </div>

        <!-- Search section -->
        <div class="flex flex-1 justify-center lg:justify-end">
          <div class="w-full px-2 lg:px-6">
            <label for="search" class="sr-only">Search projects</label>
            <div class="relative text-indigo-200 focus-within:text-gray-400">
              <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <!-- Heroicon name: mini/magnifying-glass -->
                <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                  <path fill-rule="evenodd" d="M9 3.5a5.5 5.5 0 100 11 5.5 5.5 0 000-11zM2 9a7 7 0 1112.452 4.391l3.328 3.329a.75.75 0 11-1.06 1.06l-3.329-3.328A7 7 0 012 9z" clip-rule="evenodd" />
                </svg>
              </div>
              <input id="search" name="search" class="block w-full rounded-md border border-transparent bg-indigo-400 bg-opacity-25 py-2 pl-10 pr-3 leading-5 text-indigo-100 placeholder-indigo-200 focus:bg-white focus:text-gray-900 focus:placeholder-gray-400 focus:outline-none focus:ring-0 sm:text-sm" placeholder="Search projects" type="search">
            </div>
          </div>
        </div>
        <div class="flex lg:hidden">
          <!-- Mobile menu button -->
          <button type="button" class="inline-flex items-center justify-center rounded-md bg-indigo-600 p-2 text-indigo-400 hover:bg-indigo-600 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-indigo-600" aria-controls="mobile-menu" aria-expanded="false">
            <span class="sr-only">Open main menu</span>
            <!--
              Icon when menu is closed.

              Heroicon name: outline/bars-3-center-left

              Menu open: "hidden", Menu closed: "block"
            -->
            <svg class="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
              <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12H12m-8.25 5.25h16.5" />
            </svg>
            <!--
              Icon when menu is open.

              Heroicon name: outline/x-mark

              Menu open: "block", Menu closed: "hidden"
            -->
            <svg class="hidden h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
              <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <!-- Links section -->
        <div class="hidden lg:block lg:w-80">
          <div class="flex items-center justify-end">
            <div class="flex">
              <a href="/?page=dashboard" class="rounded-md px-3 py-2 text-sm font-medium text-indigo-200 hover:text-white" aria-current="page">Dashboard</a>

              <a href="/?page=logout" class="rounded-md px-3 py-2 text-sm font-medium text-indigo-200 hover:text-white">Logout</a>
            </div>
            <!-- Profile dropdown -->
            <div class="relative ml-4 flex-shrink-0">
              <div>
                <button type="button" class="flex rounded-full bg-indigo-700 text-sm text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-indigo-700" id="user-menu-button" aria-expanded="false" aria-haspopup="true">
                  <span class="sr-only">Open user menu</span>
                  <img class="h-8 w-8 rounded-full" src="<?php echo get_picture($connect);?>" alt="">
                </button>
              </div>

              <!--
                Dropdown menu, show/hide based on menu state.

                Entering: "transition ease-out duration-100"
                  From: "transform opacity-0 scale-95"
                  To: "transform opacity-100 scale-100"
                Leaving: "transition ease-in duration-75"
                  From: "transform opacity-100 scale-100"
                  To: "transform opacity-0 scale-95"
              -->
             
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Mobile menu, show/hide based on menu state. -->
    <div class="lg:hidden" id="mobile-menu">
      <div class="space-y-1 px-2 pt-2 pb-3">
        <!-- Current: "text-white bg-indigo-800", Default: "text-indigo-200 hover:text-indigo-100 hover:bg-indigo-600" -->
        <a href="#" class="text-white bg-indigo-800 block px-3 py-2 rounded-md text-base font-medium" aria-current="page">Dashboard</a>

        <a href="#" class="text-indigo-200 hover:text-indigo-100 hover:bg-indigo-600 block px-3 py-2 rounded-md text-base font-medium">Settings</a>
      </div>
      <div class="border-t border-indigo-800 pt-4 pb-3">
        <div class="space-y-1 px-2">
        </div>
      </div>
    </div>
  </nav>

  <div class="flex-1 xl:overflow-y-auto">
            <div class="mx-auto max-w-3xl py-10 px-4 sm:px-6 lg:py-12 lg:px-8">
              <h1 class="text-3xl font-bold tracking-tight text-blue-gray-900">Account</h1>

              
                <div class="grid grid-cols-1 gap-y-6 sm:grid-cols-6 sm:gap-x-6">
                  <div class="sm:col-span-6">
                    <h2 class="text-xl font-medium text-blue-gray-900">Profile</h2>
                    <p class="mt-1 text-sm text-blue-gray-500">This information will be displayed publicly so be careful what you share.</p>
                  </div>

                  <div class="sm:col-span-3">
                    <label for="first-name" class="block text-sm font-medium text-blue-gray-900">First name</label>
                    <input type="text" name="first-name" id="first-name" autocomplete="given-name" class="mt-1 block w-full border rounded-md border-gray-400 text-blue-gray-900 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm">
                  </div>

                  <div class="sm:col-span-3">
                    <label for="last-name" class="block text-sm font-medium text-blue-gray-900">Last name</label>
                    <input type="text" name="last-name" id="last-name" autocomplete="family-name" class="mt-1 block w-full border rounded-md border-gray-400 text-blue-gray-900 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm">
                  </div>

                  <div class="sm:col-span-6">
                    <label for="username" class="block text-sm font-medium text-blue-gray-900">Username</label>
                    <div class="mt-1 flex rounded-md shadow-sm">
                      
                      <input type="text" name="username" id="username" autocomplete="username"  class="block w-full min-w-0 flex-1 border  rounded-md border-gray-400 text-blue-gray-900 focus:border-blue-500 focus:ring-blue-500 sm:text-sm">
                    </div>
                  </div>
                  <form action="/?page=upload" method="POST" enctype="multipart/form-data">
                  <div class="sm:col-span-6">
                    <label for="photo" class="block text-sm font-medium text-blue-gray-900">Photo</label>
                    <div class="mt-1 flex items-center">
                      <img class="inline-block h-12 w-12 rounded-full" src="<?php echo get_picture($connect);?>" alt="">
                      <div class="ml-4 flex">
                        <div class="relative flex cursor-pointer items-center rounded-md border border-blue-gray-300 bg-white py-2 px-3 shadow-sm focus-within:outline-none focus-within:ring-2 focus-within:ring-blue-500 focus-within:ring-offset-2 focus-within:ring-offset-blue-gray-50 hover:bg-blue-gray-50">
                          <label for="user-photo" class="pointer-events-none relative text-sm font-medium text-blue-gray-900">
                            <span>Change</span>
                            <span class="sr-only"> user photo</span>
                          </label>
                          <input id="fileToUpload" name="fileToUpload" type="file" class="absolute inset-0 h-full w-full cursor-pointer rounded-md border-gray-300 opacity-0">
                        </div>
                        <input type="submit" name ="submit" class="ml-3 rounded-md border border-gray-400 bg-transparent py-2 px-3 text-sm font-medium text-blue-gray-900 hover:text-blue-gray-800 focus:border-blue-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-blue-gray-50" value="Upload Image">
                      </div>
                    </div>
                  </div>
                  </form>

                  <div class="sm:col-span-6">
                    <label for="description" class="block text-sm font-medium text-blue-gray-900">Description</label>
                    <div class="mt-1">
                      <textarea id="description" name="description" rows="4" class="block w-full rounded-md border border-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"></textarea>
                    </div>
                    <p class="mt-3 text-sm text-blue-gray-500">Brief description for your profile. URLs are hyperlinked.</p>
                  </div>

                  <div class="sm:col-span-6">
                    <label for="url" class="block text-sm font-medium text-blue-gray-900">URL</label>
                    <input type="text" name="url" id="url" class="mt-1 block w-full rounded-md border border-gray-400 text-blue-gray-900 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm">
                  </div>
                </div>

                <div class="grid grid-cols-1 gap-y-6 pt-8 sm:grid-cols-6 sm:gap-x-6">
                  <div class="sm:col-span-6">
                    <h2 class="text-xl font-medium text-blue-gray-900">Personal Information</h2>
                    <p class="mt-1 text-sm text-blue-gray-500">This information will be displayed publicly so be careful what you share.</p>
                  </div>

                  <div class="sm:col-span-3">
                    <label for="email-address" class="block text-sm font-medium text-blue-gray-900">Email address</label>
                    <input type="text" name="email-address" id="email-address" autocomplete="email" class="mt-1 block w-full rounded-md border border-gray-400 text-blue-gray-900 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm">
                  </div>

                  <div class="sm:col-span-3">
                    <label for="phone-number" class="block text-sm font-medium text-blue-gray-900">Phone number</label>
                    <input type="text" name="phone-number" id="phone-number" autocomplete="tel" class="mt-1 block w-full rounded-md border border-gray-400 text-blue-gray-900 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm">
                  </div>

                  <div class="sm:col-span-3">
                    <label for="country" class="block text-sm font-medium text-blue-gray-900">Country</label>
                    <select id="country" name="country" autocomplete="country-name" class="mt-1 block w-full rounded-md border border-gray-400 text-blue-gray-900 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm">
                      <option></option>
                      <option>United States</option>
                      <option>Canada</option>
                      <option>Mexico</option>
                    </select>
                  </div>

                  <div class="sm:col-span-3">
                    <label for="language" class="block text-sm font-medium text-blue-gray-900">Language</label>
                    <input type="text" name="language" id="language" class="mt-1 block w-full rounded-md border border-gray-400 text-blue-gray-900 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm">
                  </div>

                  <p class="text-sm text-blue-gray-500 sm:col-span-6">This account was created on <time datetime="2017-01-05T20:35:40">January 5, 2022, 8:35:40 PM</time>.</p>
                </div>

                <div class="flex justify-end pt-8">
                  <button type="button" class="rounded-md border border-gray-300 bg-white py-2 px-4 text-sm font-medium text-blue-gray-900 shadow-sm hover:bg-blue-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">Cancel</button>
                  <button type="submit" class="ml-3 inline-flex justify-center rounded-md border border-transparent bg-blue-600 py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">Save</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>
</body>

</html>