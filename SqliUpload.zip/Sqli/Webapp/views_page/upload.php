<?php
if (!$_SESSION["username"])
{
    die(header('Location: /?page=home'));
}
include "../config.php";
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
//$target_file = "uploads/profile." . $imageFileType;

if(!isset($_POST['submit']))
{
    die(header("Location: /?page=dashboard"));
}


// Check if file already exists
if (file_exists($target_file)) {
  //echo "Sorry, file already exists.";
  require '../views_page/error.php';
  die();
  $uploadOk = 0;
}

// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
  require '../views_page/error_size.php';
  die();
  $uploadOk = 0;
}

// Allow certain file formats
$blacklist = ["txt","zip","rar","html","css","gz"];
foreach($blacklist as $key=>$ext)
{
    if($imageFileType == $ext)
    {
        require '../views_page/error_only.php';
        die();
        $uploadOk = 0;
    }
}


// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    require '../views_page/error_upload.php';
    die();
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
    require '../views_page/success.php';
    $query = "update users set photo=? where username=?";
    if($stmt = mysqli_prepare($connect, $query))
    {
      mysqli_stmt_bind_param($stmt, 'ss', $photo, $username);
      $photo = "/{$target_file}";
      $username = $_SESSION['username'];
      mysqli_stmt_execute($stmt);
    }
    die();
  } else {
    require '../views_page/error.php';
    die();
  }
}
?>
