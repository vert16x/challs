<?php 


phpinfo();

?>
