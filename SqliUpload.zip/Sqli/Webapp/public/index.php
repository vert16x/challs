<?php
session_start();
require "../app/functions/pages/pages.php";
require "../app/functions/get_images/get_images.php"; 
require load();
