<?php


function get_picture($connect)
{

    $query = "SELECT photo from users" ;

    $result = mysqli_query($connect,$query);
    
    $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
    return $rows[0]['photo'];

}