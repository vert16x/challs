<?php

function load()
{
    $page = filter_input(INPUT_GET, 'page', FILTER_SANITIZE_STRING);

    $page = (!$page) ? '../views_page/home.php' : "../views_page/{$page}.php";

    if(!file_exists($page))
    {
        $page = '../views_page/404.php';
    }

    return $page;
}


