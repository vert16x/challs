<?php

$connect = mysqli_connect("127.0.0.1","root","root","app");

if(mysqli_connect_errno($connect))
{
     echo "<font style=\"color:#FF0000\">Could not connect:". mysqli_connect_error()."</font\>";
}
