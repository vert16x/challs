<?php
$agent = $_SERVER["HTTP_USER_AGENT"];
if(strstr(strtolower($agent), "googlebot"))
{
    die("CATHO-CTF{G00gl3_Cr4wler_Us3r_4g3nt}");
}     
else{
    
    die("You're not google! " . $agent);
 }