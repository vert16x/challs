<?php

require "../functions/pages/pages.php";
require load();