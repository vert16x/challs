<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>URL Checker</title>
</head>
<body>
    <div class="min-h-full">
        <nav class="bg-green-700 shadow-sm">
          <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div class="flex h-16 justify-between">
              <div class="flex">
                <div class="flex flex-shrink-0 items-center">
                  <img class="block h-12 w-auto lg:hidden" src="https://cdn-icons-png.flaticon.com/512/2345/2345470.png" alt="Your Company">
                  <img class="hidden h-12 w-auto lg:block" src="https://cdn-icons-png.flaticon.com/512/2345/2345470.png" alt="Your Company">
                </div>
                <div class="hidden sm:-my-px sm:ml-6 sm:flex sm:space-x-8">
                  <!-- Current: "border-indigo-500 text-gray-900", Default: "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" -->
                  <a href="#" class="text-gray-900 inline-flex items-center px-1 pt-1  text-lg font-medium" aria-current="page">Safe URL Checker</a>
                </div>
              </div>
              <div class="hidden sm:ml-6 sm:flex sm:items-center">
                
              </div>
      
                  <!--
                    Dropdown menu, show/hide based on menu state.
      
                    Entering: "transition ease-out duration-200"
                      From: "transform opacity-0 scale-95"
                      To: "transform opacity-100 scale-100"
                    Leaving: "transition ease-in duration-75"
                      From: "transform opacity-100 scale-100"
                      To: "transform opacity-0 scale-95"
                  -->
                 
                </div>
              </div>
              <div class="-mr-2 flex items-center sm:hidden">
                <!-- Mobile menu button -->
                <button type="button" class="inline-flex items-center justify-center rounded-md bg-white p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2" aria-controls="mobile-menu" aria-expanded="false">
                  <span class="sr-only">Open main menu</span>
                  <!--
                    Heroicon name: outline/bars-3
      
                    Menu open: "hidden", Menu closed: "block"
                  -->
                  <svg class="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                  </svg>
                  <!--
                    Heroicon name: outline/x-mark
      
                    Menu open: "block", Menu closed: "hidden"
                  -->
                  <svg class="hidden h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
      
          <!-- Mobile menu, show/hide based on menu state. -->
          <div class="sm:hidden" id="mobile-menu">
            <div class="space-y-1 pt-2 pb-3">
              
            </div>
            <div class="border-t border-gray-200 pt-4 pb-3">
              <div class="flex items-center px-4">
                <div class="flex-shrink-0">
                  <img class="h-10 w-10 rounded-full" src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" alt="">
                </div>
                <div class="ml-3">
                  
                </div>
                <button type="button" class="ml-auto flex-shrink-0 rounded-full bg-white p-1 text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
                  <span class="sr-only">View notifications</span>
                  <!-- Heroicon name: outline/bell -->
                  <svg class="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" />
                  </svg>
                </button>
              </div>
              <div class="mt-3 space-y-1">
              </div>
            </div>
          </div>
        </nav>
      
        <div class="py-10">
          <header>
            <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
              <h1 class="text-3xl font-mono leading-tight tracking-tight text-gray-900">Free URL scanner and Website checker to detect phishing, scam sites & fraudulent sites</h1>
            </div></header></br>
          </header>
          <main>
            <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
              <p class="text-green-700">URL checker is a free tool to detect malicious URLs including malware, scam and phishing links.
                Safe link checker scan URLs for malware, viruses, scam and phishing links.
                Website checker verifies whether or not a website is legit, phishing or a scam</p></br>
                <form action="check_url.php" method="POST">
                <h1 class="text-3xl font-sans leading-tight tracking-tight text-gray-900">Check if a website is legit, phishing or scam website</h1>
                <div class="mt-1 pt-2">
                    <input type="text" name="url"  class="block w-full border rounded-md border-gray-400 py-3 px-4  focus:border-indigo-100 focus:ring-indigo-100" placeholder="https://example.com">
                </div>
                <div class="sm:col-span-2 pt-4">
                    <button type="submit" class="inline-flex w-full items-center justify-center rounded-md border border-transparent bg-green-700 px-6 py-3 text-base font-medium text-white shadow-sm hover:bg-green-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">Check</button>
                </div>
                </form>
                
              <div class="px-4 py-8 sm:px-0">
              <div class="h-96 ">

              </div>
              </div>
              <!-- /End replace -->
            </div>
          </main>
        </div>
      </div>
     <!--/config.php-->
</body>
</html>
