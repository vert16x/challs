<?php

if($_SERVER['REMOTE_ADDR'] == "127.0.0.1")
{
  $flag = "CATHO-CTF{34sy_S3rv3r_s1d3_r3qu3st_f0rg3ry}";
  echo $flag;
  
}

echo "You do not have access to this page, it is only available for localhost!";
