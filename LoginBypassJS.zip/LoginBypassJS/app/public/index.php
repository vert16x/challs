<?php

require "../pages/functions/pages.php";
require load();