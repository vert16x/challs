function Login() {
    var done=0;
    var username = document.getElementsByName('username')[0].value;
    username=username.toLowerCase();
    var password= document.getElementsByName('password')[0].value;
    password=password.toLowerCase();
    if (username== "" || password== "") {
        alert("Username and password fields are required!");
    }
    else if(username == "admin" && password=="superp@ssw0rd2k22"){
            window.location="/?page=ship_admin_page";
            done=1;
    }
    else{ 
        alert("Username or Password is incorrect!");
        done=0; 
    }
  }