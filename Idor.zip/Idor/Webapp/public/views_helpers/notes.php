<tr>
  <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
    <?php echo $key[1]; ?>
  </td>
  <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500"><?php echo $key[2]; ?></td>
  <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500"><?php echo $key[3]; ?></td>
  <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500"><?php echo $key[4]; ?></td>
</tr>