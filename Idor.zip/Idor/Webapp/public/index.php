<?php

session_start();

require "../app/functions/pages/pages.php";

load();