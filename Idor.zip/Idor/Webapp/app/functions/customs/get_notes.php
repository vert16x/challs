<?php
function getNotes($id)
{
    require_once "../config.php";
    $sql = "SELECT * FROM notes WHERE user_id = ?";

    $statement = $link->prepare($sql);
    mysqli_stmt_bind_param($statement, "s", $id);
    $statement->execute();
    $result = $statement->get_result()->fetch_all();
    foreach($result as $key)
    {
        require "views_helpers/notes.php";
        
    }
}