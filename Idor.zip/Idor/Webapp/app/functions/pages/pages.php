<?php
function load()
{
    $page = filter_input(INPUT_GET, 'page', FILTER_SANITIZE_STRING);

    $page = (!$page) ? 'views/home.php' : "views/{$page}.php";

    if(!file_exists($page))
    {
        $page = 'views/404.php';
    }

    require_once $page;
}